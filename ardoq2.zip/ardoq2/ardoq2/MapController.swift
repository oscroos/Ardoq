//
//  MapController.swift
//  ardoq2
//
//  Created by Oscar Christopher Roos on 14/11/2020.
//

import UIKit
import MapKit
import CoreLocation

//globale variabler med default verdier
var latitude: CLLocationDegrees = 0
var longitude: CLLocationDegrees = 0
var address: String = "Unknown address"
var subtitle : String = "Data not available"

class MapController: UIViewController {
    
    //NB: Å vise brukerens posisjon vil ikke fungere i simulator, men kun når man faktisk kjører appen på en mobil enhet.

    @IBOutlet weak var map: MKMapView!
    
    //for å håndtere brukerens posisjon
    fileprivate let locationManager: CLLocationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //ber om tillatelse til å bruke brukerens posisjon, samt instruerer kartet om å oppdatere brukerens posisjon. Kilde: https://medium.com/hackernoon/mapkit-display-map-and-track-user-location-with-7-lines-of-swift-in-xcode-26bde7a5646d
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        locationManager.startUpdatingLocation()
        map.showsUserLocation = true
        
        //setter koordinatene til den gjeldende stasjonen
        let currentLocation = CLLocationCoordinate2DMake(latitude, longitude)
        
        //setter kartets startverdier
        let span = MKCoordinateSpan(latitudeDelta: 0.002, longitudeDelta: 0.002)
        let region = MKCoordinateRegion(center: currentLocation, span: span)
        map.setRegion(region, animated: true)
        
        //annotasjonen til den gjeldende lokasjonen
        let annotation = MKPointAnnotation()
        annotation.coordinate = currentLocation
        annotation.title = address
        annotation.subtitle = subtitle
        
        map.addAnnotation(annotation)
        
        //setter alle andre lokasjoner
        for station in sortedDic { //station på formen [name, address, lat, lon, num_bikes_available, num_docks_available]
            
            //hopper over den stasjonen brukeren trykket på
            if station[1] == address {
                continue
            }
            //henter lat og lon og gjør om til CLLocationDegrees
            let latDegree = CLLocationDegrees(Double(station[2]) ?? 0)
            let lonDegree = CLLocationDegrees(Double(station[3]) ?? 0)
            
            //definerer nødvendige verdier: lokasjon, tittel, undertittel
            let loc = CLLocationCoordinate2DMake(latDegree, lonDegree)
            let tit = station[1]
            let sub_tit = "Available bikes: \(station[4])\nAvailable docks: \(station[5])"
            
            //definerer annotasjonen og setter den på kartet
            let ann = MKPointAnnotation()
            ann.coordinate = loc
            ann.title = tit
            ann.subtitle = sub_tit
            map.addAnnotation(ann)
        }
        

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
