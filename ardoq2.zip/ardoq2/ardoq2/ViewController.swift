//
//  ViewController.swift
//  ardoq2
//
//  Created by Oscar Christopher Roos on 13/11/2020.
//

import UIKit
import CoreLocation


var sortedDic = [[String]]() //[name, address, lat, lon, num_bikes_available, num_docks_available]

class ViewController: UIViewController {

    //variabler knyttet til UI
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableHeight: NSLayoutConstraint!
    @IBOutlet weak var lastUpdateLabel: UILabel!
    @IBOutlet weak var refreshButton: UIButton!
    @IBOutlet weak var imageView: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    //henter data og laster inn siden (på nytt)
    @objc func loadData() {
        self.viewWillAppear(true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tableView.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        
        //endrer bildeformatet for større skjermer som iPad
        if UIScreen.main.bounds.width > 450 {
            imageView.contentMode = .scaleAspectFit
        }
        
        //setter logoen
        imageView.image = UIImage(named: "oslo bysykkel logo 2")
        
        //henter og behandler data fra nettsiden
        self.getJSON1()
        
        //setter et kall til loadData() når refresh trykkes
        refreshButton.addTarget(self, action: #selector(self.loadData), for: .touchUpInside)


        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.tableView.removeObserver(self, forKeyPath: "contentSize")
        //TODO: LAST UPDATED DISPLAY
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "contentSize" {
            if object is UITableView {
                if let newValue = change?[.newKey] {
                    let newSize = newValue as! CGSize
                    self.tableHeight.constant = newSize.width
                }
            }
        }
    }
    
    
    
    //DATA-DELEN
    //URLs
    let URL_INFO = "https://gbfs.urbansharing.com/oslobysykkel.no/station_information.json"
    let URL_STATUS = "https://gbfs.urbansharing.com/oslobysykkel.no/station_status.json"
    
    //Lagrer dataen i dictionary
    var station_dic = [NSString: [NSString]]() //[station_id : [name, address]]
    
    //definerer nødvendige variabler med default verdier
    var last_update = 0
    var seconds : Int = 0
    var timer = Timer()
    let greenColor = UIColor(displayP3Red: 53/255, green: 175/255, blue: 33/255, alpha: 1.0)
    
    //Øker timeren med 1 sekund for hvert kall, opp til 60 sek
    @objc func updateTimerOneSec() {
        self.seconds += 1
        if seconds < 60 {
            self.lastUpdateLabel.text = "Last update: \(seconds) seconds ago"
            
            //oppdaterer farge
            if self.lastUpdateLabel.backgroundColor == UIColor.red {
                self.lastUpdateLabel.backgroundColor = greenColor
            }
            
        }
        else {
            self.lastUpdateLabel.text = "Last update: >1 minute ago"
            
            //oppdaterer farge
            self.lastUpdateLabel.backgroundColor = .red
            timer.invalidate()
        }
    }
    
    //Setter startverdien for timeren. Beregnes ved å ta UNIX time per nå minus UNIX time oppgitt i URL_STATUS
    func setTimer(time: Int) {
        //avslutter forrige timer
        timer.invalidate()
        
        //oppdaterer farge
        if self.lastUpdateLabel.backgroundColor == UIColor.red {
            self.lastUpdateLabel.backgroundColor = greenColor
        }

        
        //beregner UNIX time per nå som heltall
        let timeNow = Int(round(Date().timeIntervalSince1970))
        self.seconds = timeNow - time
        self.lastUpdateLabel.text = "Last update: \(seconds) seconds ago"
        
        //setter timeren til å kalle updateTimerOneSec() hvert sekund
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(self.updateTimerOneSec)), userInfo: nil, repeats: true)
        
        //For at timeren skal oppdateres mens man scroller. Hentet fra: https://stackoverflow.com/questions/34234939/swift-nstimer-stop-when-scrolling/34235615
        RunLoop.main.add(timer, forMode: RunLoop.Mode.common)
        


    }
    
    //henter dataen fra URL_INFO og lagrer den i dictionaries
    func getJSON1() {
        let url = URL(string: URL_INFO)
        //completionHandler utføres etter at dataen er hentet
        URLSession.shared.dataTask(with: url!, completionHandler: {(data, response, error) -> Void in
            if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary {
                
                let data = jsonObj.value(forKey: "data") //en NSDictionary med den ene nøkkelen "stations"
                let stations = (data as! NSDictionary)["stations"] //liste med en dictionary som elementer
                for station in (stations as! NSArray) { //går gjennom alle dictionariene og lagrer interessante verdier
                    let lat : NSString = ("\((station as! NSDictionary)["lat"] ?? "unknown")") as NSString
                    let lon : NSString = ("\((station as! NSDictionary)["lon"] ?? "unknown")") as NSString
                    
                    self.station_dic[((station as! NSDictionary)["station_id"]) as! NSString] = [((station as! NSDictionary)["name"]) as! NSString, ((station as! NSDictionary)["address"]) as! NSString, lat, lon]
                }
                
                //kaller tilsvarende funksjon for URL_STATUS
                self.getJSON2()
                
                //utføres etter at dataen er hentet
                DispatchQueue.main.async {
                    //oppdaterer informasjonen i brukergrensesnittet
                    self.tableView.reloadData()
                }
            }
        }).resume()
        
    }
    

    //henter dataen fra URL_INFO og lagrer den i dictionaries
    func getJSON2() {
        let url = URL(string: URL_STATUS)
        URLSession.shared.dataTask(with: url!, completionHandler: {(data, response, error) -> Void in
            if let jsonObj = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? NSDictionary {
                
                //henter, konverterer til Int og lagrer tiden for oppdateringen i UNIX time
                let updateTime = ("\(jsonObj.value(forKey: "last_updated") ?? "0")")
                self.last_update = Int(updateTime)!
                
                
                let data = jsonObj.value(forKey: "data") // en NSDictionary med den ene nøkkelen "stations"
                let stations = (data as! NSDictionary)["stations"] //liste med en dictionary per element
                for station in (stations as! NSArray) {
                    
                    //legger verdier til i station_dic
                    let num_bikes_available : NSString = ("\((station as! NSDictionary)["num_bikes_available"] ?? "unknown")") as NSString
                    self.station_dic[((station as! NSDictionary)["station_id"]) as! NSString]?.append(num_bikes_available)
                    
                    let num_docks_available : NSString = ("\((station as! NSDictionary)["num_docks_available"] ?? "unknown")") as NSString
                    self.station_dic[((station as! NSDictionary)["station_id"]) as! NSString]?.append(num_docks_available)
                }
                
                //setter timerens startverdi og refresher UI etter at dataen er hentet
                DispatchQueue.main.async {
                    self.setTimer(time: Int(self.last_update))
                    self.tableView.reloadData()

                }
            }
    
        }).resume()
    }
}

    


extension ViewController:UITableViewDelegate,UITableViewDataSource {
    
    //setter antall celler i tableView til å være likt antall stasjoner
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        //sorterer verdiene i sortedDic alfabetisk etter navnet på stasjonen. Implementeres her for å unngå alt for mange unødvendige sorteringer.
        sortedDic = (self.station_dic as [String: [String]]).values.sorted(by:
            {(a, b) -> Bool in
            return a[0] < b[0]
        })

        return station_dic.keys.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "TestCell", for: indexPath) as? TestCell {
            
            //en if-setning som forsikrer at vi har lastet inn nok data før man forsøker å vise dataen til brukeren
            if sortedDic[indexPath.row].count > 4 {
                
                //henter info for den aktuelle stasjonen
                let name = sortedDic[indexPath.row][0]
                let availableBikes = sortedDic[indexPath.row][4]
                let availableDocks = sortedDic[indexPath.row][5]
                
                //definerer en formulering som skal vises til brukeren
                let title = "\(name)  (\(availableBikes)/\(availableDocks))"
                //setter denne formuleringen på en button (i sortert rekkefølge)
                cell.button.setTitle(title, for: .normal)
            }
            else {
                cell.button.setTitle("\(sortedDic[indexPath.row][0])", for: .normal)
            }
            
            //gir hver button en unik tag slik at man senere kan gjenkjenne hvilken knapp som trykkes
            cell.button.tag = indexPath.row

            //setter et kall til buttonPressed() når hvilken som helst av knappene med stasjonsnavn trykkes
            cell.button.addTarget(self, action: #selector(self.buttonPressed(sender:)), for: .touchUpInside)
            return cell
        }
        return UITableViewCell()
    }
    
    //kalles hver gang en knapp med stasjonsnavn trykkes
    @objc func buttonPressed(sender: UIButton) {
        //henter dataen tilhørende den stasjonen med navnet sitt på knappen som trykkes
        let attributes = sortedDic[sender.tag] //[name, address, lat, lon, num_bikes_available, num_docks_available]
        let lat = attributes[2]
        let lon = attributes[3]
        
        //gjør om til Double
        let latDouble = Double(lat)
        let lonDouble = Double(lon)
        
        //konstruerer en subtitle
        let subtitleString = "Available bikes: \(attributes[4])\nAvailable docks: \(attributes[5])"

        //lagrer verdiene i de globale variablene
        latitude = CLLocationDegrees(latDouble ?? 0)
        longitude = CLLocationDegrees(lonDouble ?? 0)
        address = attributes[1]
        subtitle = subtitleString
        
        //sender brukeren til kartet
        performSegue(withIdentifier: "toMap", sender: sender)
        
    }
    
}
