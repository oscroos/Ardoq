//
//  TestCell.swift
//  ardoq2
//
//  Created by Oscar Christopher Roos on 13/11/2020.
//

import UIKit

class TestCell: UITableViewCell {

    @IBOutlet weak var button: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
